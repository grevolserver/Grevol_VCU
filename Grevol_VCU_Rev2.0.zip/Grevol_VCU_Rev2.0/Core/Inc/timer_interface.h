/*
 * timmer_interface.h
 *
 *  Created on: Feb 1, 2025
 *      Author: deepa
 */


void
timmer_init(void);

uint8_t
timmer_get_1ms_tick(void);
