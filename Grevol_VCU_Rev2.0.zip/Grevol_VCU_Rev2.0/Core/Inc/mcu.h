/*
 * mcu.h
 *
 *  Created on: Fab 10, 2025
 *      Author: deepa
 */

#ifndef INC_MCU_H_
#define INC_MCU_H_


#include "stdint.h"

#ifndef VCU_ALGORITHMS_H
#define VCU_ALGORITHMS_H

#include <stdint.h>
#include <stdbool.h>

// Structure to hold all VCU-related data
typedef struct {
    float analogInput;
    float dcBusVoltage;
    float rmsValue;
    bool  faultFlag;
    bool  postPassed;
    // Add more variables as per your system signals
} VCU_Data;

// Function Declarations
void DebounceFilter(VCU_Data *data);
void RMSComputation(VCU_Data *data);
void AnalogHysteresis(VCU_Data *data, float upperLimit, float lowerLimit);
void SinglePersistenceLogic(bool inputSignal, uint8_t requiredCount, bool *outputSignal);
void FaultHandling(VCU_Data *data);
void PowerOnSelfTest(VCU_Data *data);
void SignalIntegrityRange(VCU_Data *data, float minVal, float maxVal);
void SDCardDataRecording(const VCU_Data *data);
void DataLoggingProtocol(const VCU_Data *data);
void DataCompression(const VCU_Data *data);
void AlgoFileHandling(void);
void SignalCalibration(VCU_Data *data);
void CANCommunication(const VCU_Data *data);
void USBFunction(void);

#endif // VCU_ALGORITHMS_H



#endif /* INC_MCU_H_ */
