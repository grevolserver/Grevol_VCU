/*
 * app.h
 *
 *  Created on: Jan 28, 2025
 *      Author: deepa
 */

#ifndef INC_APP_H_
#define INC_APP_H_
void
app_process(void)


#endif /* INC_APP_H_ */
