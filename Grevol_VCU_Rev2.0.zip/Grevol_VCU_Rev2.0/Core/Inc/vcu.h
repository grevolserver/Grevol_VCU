/*
 * vcu.h
 *
 *      Author: deepa
 */

#ifndef INC_VCU_H_
#define INC_VCU_H_

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

bool CAN_Receive(CAN_Message *msg);

bool SD_WriteBlock(uint8_t *data, uint32_t blockNumber);

float ReadADCChannel(int channel);

int vcu_process(void);

#endif /* INC_VCU_H_ */
