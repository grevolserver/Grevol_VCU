/*
 * timer_interface.c
 *
 *  Created on: Feb 1, 2025
 *      Author: deepa
 */
#include "stdint.h"

// Function has to handle the timer initlization.
void
timmer_init(void)
{

}

// function to return 1ms tick
uint8_t
timmer_get_1ms_tick(void)
{
	return 1;

}


