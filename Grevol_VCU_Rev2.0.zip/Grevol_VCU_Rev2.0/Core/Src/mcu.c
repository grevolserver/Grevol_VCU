#include "mcu.h"
#include <stdio.h>
#include <math.h>

// -------------------- Debounce / Filter --------------------
void DebounceFilter(VCU_Data *data) {
    // Purpose: Remove glitches/noise from digital/analog input signals.
    // Method: Apply a simple moving average or time-based counter filter.

    static float prevValue = 0;
    float alpha = 0.1f; // filter coefficient

    data->analogInput = (alpha * data->analogInput) + ((1 - alpha) * prevValue);
    prevValue = data->analogInput;
}

// -------------------- RMS Computation --------------------
void RMSComputation(VCU_Data *data) {
    // Purpose: Compute RMS value of the DC bus voltage
    // Formula: RMS = sqrt( (1/N) * Σ(x^2) )

    static float sumSquares = 0;
    static uint16_t sampleCount = 0;

    sumSquares += data->dcBusVoltage * data->dcBusVoltage;
    sampleCount++;

    if (sampleCount >= 1000) { // example window size
        data->rmsValue = sqrtf(sumSquares / sampleCount);
        sumSquares = 0;
        sampleCount = 0;
    }
}

// -------------------- Analog Hysteresis --------------------
void AnalogHysteresis(VCU_Data *data, float upperLimit, float lowerLimit) {
    // Purpose: Prevent signal from toggling rapidly around a threshold.
    static bool state = false;

    if (!state && data->analogInput > upperLimit) {
        state = true;
    } else if (state && data->analogInput < lowerLimit) {
        state = false;
    }
    // You could store the result in data->faultFlag or another variable
}

// -------------------- Single Persistence Logic --------------------
void SinglePersistenceLogic(bool inputSignal, uint8_t requiredCount, bool *outputSignal) {
    // Purpose: Only change output if input remains in the same state for N samples.
    static uint8_t counter = 0;

    if (inputSignal) {
        if (counter < requiredCount) counter++;
    } else {
        counter = 0;
    }

    *outputSignal = (counter >= requiredCount);
}

// -------------------- Fault Handling --------------------
void FaultHandling(VCU_Data *data) {
    // Purpose: Monitor signals and set faultFlag if abnormal conditions detected.
    if (data->dcBusVoltage > 60.0f || data->dcBusVoltage < 10.0f) {
        data->faultFlag = true;
    } else {
        data->faultFlag = false;
    }
}

// -------------------- Power On Self Test (POST) --------------------
void PowerOnSelfTest(VCU_Data *data) {
    // Purpose: Perform initial checks at startup.
	float adc_data;

	if(adc_data < *data->analogInput)
	{
		data->postPassed = flase;
	}

	else if(adc_data < *data->dcBusVoltage)
	{
		data->postPassed = flase; // bus voltage fault
	}

	else if(adc_data < *data->rmsValue)
	{
		data->postPassed = flase; // bus voltage fault
	}
	else
	{
		data->postPassed = true; // Set to false if any test fails
	}
}

// -------------------- Signal Integrity Range Check --------------------
void SignalIntegrityRange(VCU_Data *data, float minVal, float maxVal) {
    // Purpose: Ensure signal remains within expected range
    if (data->analogInput < minVal || data->analogInput > maxVal) {
        data->faultFlag = true;
    }
}

// Example buffer parameters
	#define CAN_DATA_BUFFER_SIZE   512   // SD card sector size
	#define CAN_MSG_MAX_SIZE       8     // max CAN frame payload

	typedef struct {
	    uint32_t id;       // CAN ID
	    uint8_t  data[CAN_MSG_MAX_SIZE];
	    uint8_t  length;   // number of valid bytes
	} CAN_Message;

	// Static buffer for SD write
	static uint8_t sdWriteBuffer[CAN_DATA_BUFFER_SIZE];
	static uint16_t bufferIndex = 0;

	// Placeholder: your CAN receive function
	extern bool CAN_Receive(CAN_Message *msg);

	// Placeholder: your SD card write function
	extern bool SD_WriteBlock(uint8_t *data, uint32_t blockNumber);


// -------------------- SD Card Data Recording --------------------
void SDCardDataRecording(const VCU_Data *data)
{
	// 1. Receive CAN data (polling example)
	if (CAN_Receive(&msg)) {
		// 2. Copy CAN payload into buffer
		if ((bufferIndex + msg.length) <= CAN_DATA_BUFFER_SIZE) {
			memcpy(&sdWriteBuffer[bufferIndex], msg.data, msg.length);
			bufferIndex += msg.length;
		}

		// 3. If buffer full, write to SD card
		if (bufferIndex >= CAN_DATA_BUFFER_SIZE) {
			static uint32_t sdBlockNumber = 0; // tracks where to write

			if (SD_WriteBlock(sdWriteBuffer, sdBlockNumber)) {
				sdBlockNumber++;
				bufferIndex = 0; // reset buffer after successful write
			} else {
				// Handle SD card write failure
				// e.g., set a fault flag or retry
			}
		}
	}
}

// ==================== Data Compression ====================
void DataCompression(const VCU_Data *data) {
    // Purpose: Reduce data size before storing/transmitting
    // Method: Delta encoding with change threshold

    static VCU_Data prevData = {0};
    const float voltageThreshold = 0.05f;  // 50 mV change
    const float rmsThreshold     = 0.01f;  // 10 mV RMS change

    bool transmit = false;

    // Compare important fields
    if (fabsf(data->dcBusVoltage - prevData.dcBusVoltage) > voltageThreshold) {
        transmit = true;
    }
    if (fabsf(data->rmsValue - prevData.rmsValue) > rmsThreshold) {
        transmit = true;
    }
    if (data->faultFlag != prevData.faultFlag) {
        transmit = true;
    }
    if (data->postPassed != prevData.postPassed) {
        transmit = true;
    }

    // Perform "compression" by only sending/storing on change
    if (transmit) {
        // Example: print compressed packet
        printf("[COMPRESSED] V=%.2f RMS=%.2f Fault=%d POST=%d\n",
               data->dcBusVoltage, data->rmsValue,
               data->faultFlag, data->postPassed);

        // Store as previous
        prevData = *data;
    }
}

// ==================== Algorithm File Handling ====================
void AlgoFileHandling(void) {
    // Purpose: Manage algorithm configuration files
    // Example: read/write calibration values from text file

    static float calibrationGain = 1.0f;
    static float calibrationOffset = 0.0f;

    // Try to open file for reading
    FILE *fp = fopen("vcu_config.txt", "r");
    if (fp) {
        if (fscanf(fp, "%f %f", &calibrationGain, &calibrationOffset) == 2) {
            printf("Config Loaded: Gain=%.3f, Offset=%.3f\n", calibrationGain, calibrationOffset);
        } else {
            printf("Config file read error, using defaults.\n");
        }
        fclose(fp);
    } else {
        // File not found, create with default values
        printf("Config file not found, creating new.\n");
        fp = fopen("vcu_config.txt", "w");
        if (fp) {
            fprintf(fp, "1.000 0.000\n");
            fclose(fp);
        }
    }

    // Apply config to system variables (optional)
    // This would normally store to a global or config structure
}

// ==================== Signal Calibration ====================
void SignalCalibration(VCU_Data *data) {
    // Purpose: Apply scaling factors or offsets
    // Normally these values would come from AlgoFileHandling()
    static float gain   = 1.05f;
    static float offset = -0.02f; // volts

    // Calibrate analog input
    data->analogInput   = (data->analogInput * gain) + offset;

    // Calibrate DC bus voltage
    data->dcBusVoltage  = (data->dcBusVoltage * gain) + offset;

    // Calibrate RMS value
    data->rmsValue      = (data->rmsValue * gain) + offset;
}

// ==================== USB Function ====================
void USBFunction(void) {
    char usbRxBuffer[64];
    char usbTxBuffer[64];

    // Simulated receive from USB (user types command)
    printf("USB> ");
    if (fgets(usbRxBuffer, sizeof(usbRxBuffer), stdin)) {
        // Remove newline
        usbRxBuffer[strcspn(usbRxBuffer, "\n")] = 0;

        // Process commands
        if (strcmp(usbRxBuffer, "GETV") == 0) {
            extern VCU_Data vcuData; // Assume global data
            snprintf(usbTxBuffer, sizeof(usbTxBuffer), "VOLT=%.2f\n", vcuData.dcBusVoltage);
            printf("USB TX: %s", usbTxBuffer);
        }
        else if (strcmp(usbRxBuffer, "STATUS") == 0) {
            extern VCU_Data vcuData;
            snprintf(usbTxBuffer, sizeof(usbTxBuffer), "FAULT=%d POST=%d\n",
                     vcuData.faultFlag, vcuData.postPassed);
            printf("USB TX: %s", usbTxBuffer);
        }
        else if (strcmp(usbRxBuffer, "HELP") == 0) {
            printf("Commands: GETV, STATUS, HELP\n");
        }
        else {
            printf("Unknown command.\n");
        }
    }
}
