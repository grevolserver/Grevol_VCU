/*
 * app.c
 *
 *  Created on: Jan 28, 2025
 *      Author: deepa
 */

void
app_process(void)
{

}
