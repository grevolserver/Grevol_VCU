/*
 * BMS.h
 *
 *  Created on: Jan 28, 2025
 *      Author: deepa
 */

#ifndef INC_BMS_H_
#define INC_BMS_H_

#include "stdint.h"

void
bms_init(void);

void
bms_soc_process(void);

uint8_t
bms_open_circuit_voltage_soc(float voltage);

float
bms_coulomb_counter_soc(float sample_current, float step_time);

uint8_t
bms_get_soc_percent(void);



#endif /* INC_BMS_H_ */
