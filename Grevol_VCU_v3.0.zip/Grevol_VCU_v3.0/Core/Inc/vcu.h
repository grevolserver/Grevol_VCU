/*
 * vcu.h
 *
 *      Author: deepa
 */

#ifndef INC_VCU_H_
#define INC_VCU_H_

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

bool SD_WriteBlock(uint8_t *data, uint32_t blockNumber);

float ReadADCChannel(int channel);

int vcu_process(void);

// Structure to hold all VCU-related data
typedef struct {
    float analogInput;
    float dcBusVoltage;
    float rmsValue;
    bool  faultFlag;
    bool  postPassed;
    // Add more variables as per your system signals
} VCU_Data;

// Function Declarations
void DebounceFilter(VCU_Data *data);
void RMSComputation(VCU_Data *data);
void AnalogHysteresis(VCU_Data *data, float upperLimit, float lowerLimit);
void SinglePersistenceLogic(bool inputSignal, uint8_t requiredCount, bool *outputSignal);
void FaultHandling(VCU_Data *data);
void PowerOnSelfTest(VCU_Data *data);
void SignalIntegrityRange(VCU_Data *data, float minVal, float maxVal);
void SDCardDataRecording(const VCU_Data *data);
void DataLoggingProtocol(const VCU_Data *data);
void DataCompression(const VCU_Data *data);
void AlgoFileHandling(void);
void SignalCalibration(VCU_Data *data);
void CANCommunication(const VCU_Data *data);
void USBFunction(void);


#endif /* INC_VCU_H_ */
