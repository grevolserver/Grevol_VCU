

#include "stdint.h"
#include "bms.h"

float  m_coulamb_soc_percent;
uint8_t  m_oc_soc_percent;
float  m_initial_soc;
float  m_bms_soc;
static float m_sample_time;

// Macro are define:

#define BATTERY_CAPACITY		 2000    // capacity of the battery in mAh
#define INITIAL_SOC				 0  	 // Initial SOC in percentage
#define MAX_SOC 				 100     // Maximum SOC
#define MIN_SOC 				 0       // Minimum SOC

#define OCV_LOOKUP_SIZE 5

static float initial_OCV_voltage;

uint16_t OCV_lookup[OCV_LOOKUP_SIZE][2]=
{
    {3.90, 100}, // Vol (3.90V) -> SOC 100%
    {3.70, 75},  // Vol (3.70V) -> SOC 75%
    {3.50, 50},  // Vol (3.50V) -> SOC 50%
    {3.30, 25},  // Vol (3.30V) -> SOC 25%
    {3.10, 0}    // Vol (3.10V) -> SOC 0%
};

void
bms_init(void)
{
	m_coulamb_soc_percent = 0u;
	m_oc_soc_percent = 0;
	m_initial_soc = INITIAL_SOC;
	m_sample_time = 0.01; // 1milisec

	//while power we compute the Battery SOC with OCV method.

	//initial_OCV_voltage = HAL_ADC_GetValue();
	m_bms_soc = bms_open_circuit_voltage_soc(initial_OCV_voltage);
}

void
bms_soc_process(void)
{
	float coulomb_soc;
	float current_measure;
	uint16_t counter_2min;

	if(timmer_get_1ms_tick())
	{
		//current_measure = HAL_ADC_GetValue();
		m_coulamb_soc_percent = bms_coulomb_counter_soc(current_measure, m_sample_time);

		if(m_coulamb_soc_percent == 0.0)
		{
			//initial_OCV_voltage = HAL_ADC_GetValue();
			m_oc_soc_percent = bms_open_circuit_voltage_soc(initial_OCV_voltage);
			m_bms_soc = m_oc_soc_percent;
		}
		else
		{
			m_bms_soc =  m_bms_soc + coulomb_soc;
		}
	}
}

// make the 0.1ah change in value in batter, time in 1min,

uint8_t
bms_open_circuit_voltage_soc(float voltage)
{
    // Simple linear interpolation
	uint8_t result;
    for (int i = 0; i < OCV_LOOKUP_SIZE - 1; i++)
    {
        if (voltage >= OCV_lookup[i + 1][0] && voltage < OCV_lookup[i][0])
        {
            double slope = (OCV_lookup[i][1] - OCV_lookup[i + 1][1]) / (OCV_lookup[i][0] - OCV_lookup[i + 1][0]);

            result = OCV_lookup[i + 1][1] + (slope * (voltage - OCV_lookup[i + 1][0]));
            return result;
        }
    }
}

float
bms_coulomb_counter_soc(float sample_current, float step_time)
{
	// As Charge = Current x time (Q=it)
   float charger_flow;

   charger_flow = (float)(sample_current * step_time); // accumulation of charge over time
   m_coulamb_soc_percent = (charger_flow / BATTERY_CAPACITY) * 100;

   if(m_coulamb_soc_percent > MAX_SOC)
   {
	   m_coulamb_soc_percent =  MAX_SOC;
   }
   if(m_coulamb_soc_percent < MIN_SOC)
   {
	   m_coulamb_soc_percent = MIN_SOC;
   }

   return m_coulamb_soc_percent;
}

uint8_t
bms_get_soc_percent(void)
{
	return m_bms_soc;
}

